# Polkascan Explorer GUI
Polkascan Explorer GUI Angular Application

## Description
The purpose of the Explorer GUI Application is to make the data which is produced by the Polkascan Harvester Application and disseminated by the Polkascan Explorer API Application accessible to day-to-day end-user. The Polkascan Explorer GUI Application provides a user interface to the Polkascan Explorer API Application and intends to showcase what developers should be able to build on top of the Polkascan Explorer API Application for a wide audience of day-to-day users.
The purpose of the Polkascan PRE Explorer GUI Application is to make the data which is produced by the Polkascan PRE Harvester Application and disseminated by the Polkascan PRE Explorer API Application accessible to day-to-day end-user. The Polkascan PRE Explorer GUI Application provides a user interface to the Polkascan PRE Explorer API Application and intends to showcase what developers should be able to build on top of the Polkascan PRE Explorer API Application for a wide audience of day-to-day users.

## License
https://github.com/polkascan/polkascan-explorer-gui/blob/master/LICENSE

